![제목 없는 다이어그램 drawio](https://github.com/sinheyy/shopping-mall-be/assets/163747140/990ca2a5-7f9f-4ac6-8d0c-8e80a14ff950)
